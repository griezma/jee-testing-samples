insert into fibos (key, fibo) values (0, 0) 
insert into fibos (key, fibo) values (1, 1) 
insert into fibos (key, fibo) values (2, 2) 